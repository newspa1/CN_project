#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <fstream>
#include <sstream>
using namespace std;

#define PORT 8080
#define BUFFER_SIZE 1024
#define USERFILE "user.txt"

void MessageHandling(string message, int clientSocket, string& status, bool& isLogin);
void Registration(string message, int clientSocket, string& status);
void Login(string message, int clientSocket, string& status, bool& isLogin);
void Logout(int clientSocket, string& status, bool& isLogin);
void AddUser(string message);
void CommandComplete(int clientSocket, string& status);
bool isUserExist(string message);

int main() {
	int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
	
	sockaddr_in serverAddress;
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_port = htons(PORT);
	serverAddress.sin_addr.s_addr = INADDR_ANY;
	
	bind(serverSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress));

	listen(serverSocket, 5);
	cout << "Server is listening on port: " << PORT << endl;

	socklen_t addrlen = sizeof(serverAddress);
	int clientSocket = accept(serverSocket, (struct sockaddr*)&serverAddress, &addrlen);
	if(clientSocket >= 0) {
		cout << "Client connected, fd = " << clientSocket << endl;
	} 

	char message[BUFFER_SIZE];
	string status = "";
	string type = "Nothing";
	send(clientSocket, type.c_str(), type.size(), 0);

	bool isLogin = false;

	while(true) {
		memset(message, 0, sizeof(message));
		recv(clientSocket, message, sizeof(message), 0);
		cout << "Recieve message from client: " << message << endl;
		MessageHandling(string(message), clientSocket, status, isLogin);

	}


	close(serverSocket);

}

void MessageHandling(string message, int clientSocket, string& status, bool& isLogin) {
	if(isLogin) {
		if(message == "Logout") {
			Logout(clientSocket, status, isLogin);
		} else {
			string type = "Nothing";
			send(clientSocket, type.c_str(), type.size(), 0);
		}
	} else {
		if(status == "") {
			if(message == "Registration") {
				Registration(message, clientSocket, status);
			} else if(message == "Login") {
				Login(message, clientSocket, status, isLogin);
			} else {
				string type = "Nothing";
				send(clientSocket, type.c_str(), type.size(), 0);
			}
		} else {
			if(status == "Registration_1") {
				Registration(message, clientSocket, status);
			} else if(status == "Login_1") {
				Login(message, clientSocket, status, isLogin);
			}
		}
	}
}

void Registration(string message, int clientSocket, string& status) {
	string type;
	if(status == "") { // Recieve Registration (message = Registration)
		type = "Registration";
    	send(clientSocket, type.c_str(), type.size(), 0);
		status = "Registration_1";
	} else if(status == "Registration_1") { // Receive client username (message = username)
		if(!isUserExist(message)) {
			AddUser(message);
			cout << "Registreation success.\n";
			type = "Registration_success";
			send(clientSocket, type.c_str(), type.size(), 0);

			CommandComplete(clientSocket, status);
		} else {
			type = "Registration_failed";
    		send(clientSocket, type.c_str(), type.size(), 0);

			CommandComplete(clientSocket, status);
		}
		status = "";
	}
}

void Login(string message, int clientSocket, string& status, bool& isLogin) {
	string type;
	if(status == "") { // Recieve Login (message = Login)
		type = "Login";
    	send(clientSocket, type.c_str(), type.size(), 0);
		status = "Login_1";
	} else if(status == "Login_1") { // Receive client username (message = username)
		if(isUserExist(message)) {
			cout << "Client Login success.\n";
			type = "Login_success";
			isLogin = true;
			send(clientSocket, type.c_str(), type.size(), 0);

			CommandComplete(clientSocket, status);
		} else {
			type = "Login_failed";
    		send(clientSocket, type.c_str(), type.size(), 0);

			CommandComplete(clientSocket, status);
		}
		status = "";
	}
}

void Logout(int clientSocket, string& status, bool& isLogin) {
	string type;
	if(status == "") { // Recieve Login (message = Logout)
		isLogin = false;
		type = "Logout";
    	send(clientSocket, type.c_str(), type.size(), 0);
	} 
}

void AddUser(string message) {
	ofstream userfile;
	userfile.open(USERFILE, ios::app);
	userfile << message + '\n';
	userfile.close();
}

void CommandComplete(int clientSocket, string& status) {
	char tmp[BUFFER_SIZE] = {0};
	string type = "Nothing";
	recv(clientSocket, tmp, sizeof(tmp), 0);
	send(clientSocket, type.c_str(), type.size(), 0);
	status = "";
}

bool isUserExist(string message) {
	ifstream userfile(USERFILE);
	string line;
	while(getline(userfile, line)) {
		istringstream iss(line);
		string username;
		iss >> username;

		if(username == message) { // User exists
			userfile.close();
			return true;
		}
	}
	userfile.close();
	return false;
}