#include <iostream>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
using namespace std;

#define PORT 8080
#define BUFFER_SIZE 1024
int clientSocket;
bool isLogin = false;

void ResponseHandling(string response);
void Registration(string response);
void Login(string response);
void Logout(string response);
bool isinRegistration(string response);
bool isinLogin(string response);
bool isinLogout(string response);
void CommandComplete();

int main() {
    clientSocket = socket(AF_INET, SOCK_STREAM, 0);

    sockaddr_in serverAddress;
	serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = inet_addr("127.0.0.1");
	serverAddress.sin_port = htons(PORT);

    if(connect(clientSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) >= 0) {
        cout << "Connect to server" << endl;
    } else {
        cout << "Connection failed" << endl;
    }
    
    char response[BUFFER_SIZE];
    while(true) {
        memset(response, 0, sizeof(response));
	    recv(clientSocket, &response, sizeof(response), 0);
	    ResponseHandling(string(response));
    }

    close(clientSocket);
}

void ResponseHandling(string response) {
    if(isLogin) {
        if(isinLogout(response)) {
            Logout(response);
        } else { // Nothing
            string message;
            cout << "Enter message: ";
            getline(cin, message);
            send(clientSocket, message.c_str(), message.size(), 0);
        }
    }
    else {
        if(isinRegistration(response)) {
            Registration(response);
        } else if(isinLogin(response)) {
            Login(response);
        } else { // Nothing
            string message;
            cout << "Registration or Login: ";
            getline(cin, message);
            send(clientSocket, message.c_str(), message.size(), 0);
        }
    }
}

void Registration(string response) {
    if(response == "Registration") {
        string message;
        cout << "Please Enter Username: ";
        getline(cin, message);
        send(clientSocket, message.c_str(), message.size(), 0);
    } else if(response == "Registration_success") {
        cout << "Registration success.\n";
        CommandComplete();
    } else if(response == "Registration_failed") {
        cout << "Registration failed.\n";
        CommandComplete();
    }

}

void Login(string response) {
    if(response == "Login") {
        string message;
        cout << "Please Enter Username: ";
        getline(cin, message);
        send(clientSocket, message.c_str(), message.size(), 0);
    } else if(response == "Login_success") {
        cout << "Login success.\n";
        isLogin = true;
        CommandComplete();
    } else if(response == "Login_failed") {
        cout << "Login failed.\n";
        CommandComplete();
    }
}

void Logout(string response) {
    if(response == "Logout") {
        string message;
        cout << "Logout.\n";
        isLogin = false;
        CommandComplete();
    }
}

bool isinRegistration(string response) {
    return (response.find("Registration") == 0);
}

bool isinLogin(string response) {
    return (response.find("Login") == 0);
}

bool isinLogout(string response) {
    return (response.find("Logout") == 0);
}

void CommandComplete() {
    string type = "Complete";
    send(clientSocket, type.c_str(), type.size(), 0);
}